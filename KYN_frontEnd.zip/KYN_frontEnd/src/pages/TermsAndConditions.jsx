import Header from "../components/Header";
import Terms from "../components/terms";

function TermsAndConditions(){
    return(
        <>
        <Header activePage={'terms'} />
        <Terms />
        </>
    )
}

export default TermsAndConditions;