import Header from "../components/Header";
import RegisterForm from "../components/Register";

function Registration(){
    return(
        <>
        <Header />
        <RegisterForm />
        </>
    )
}

export default Registration;