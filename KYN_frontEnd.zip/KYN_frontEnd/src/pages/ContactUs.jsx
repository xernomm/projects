import Header from "../components/Header";
import Contact from "../components/contact";

function ContactUs(){
    return(
        <>
        <Header activePage={'contact-us'} />
        <Contact />
        </>
    )
}
export default ContactUs;