import Header from "../components/Header";
import RegisSuccess from "../components/regisSuccess";

function RegisterSuccess(){
    return (
        <>
        <Header />
        <RegisSuccess />
        </>

    )
}

export default RegisterSuccess;