import Header from "../components/Header";
import LandingBody from "../components/landingBody";

function Login(){
return(
    <>
    <Header activePage={'home'}/>
    <LandingBody />
    </>
)
}

export default Login;