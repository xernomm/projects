import React, { useState } from 'react';
import { Form, Button, Row, Col, Container } from 'react-bootstrap';
import FacebookLoginBtn from './FacebookLogin';
import axios from 'axios';

const RegisterForm = () => {
  const [name, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginName, setLoginName] = useState('');
  const [loginPassword, setPasswordLogin] = useState('');
  const [showReplacement, setShowReplacement] = useState(false);
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState(false);
  const [validated, setValidated] = useState(false);



  const handleSubmit = (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      setPasswordError(true);
      return;
    }
    const user = {
      name: name,
      email: email,
      password: password,
    };
  
    axios.post('http://localhost:8080/user/register', user)
      .then(response => {
      alert("Register Successfull")
       window.location.href = "/login"
        console.log(response.data);
      })
      .catch(error => {
        alert("Error Occured");
        console.error(error);
      });

  };

  const handleLoginFormSubmit = async (e) => {
    e.preventDefault(); // Prevent form submission
    setValidated(true);
  
    if (e.target.checkValidity()) {
      // Create an object with the form data
      const user = {
        email: loginName,
        password: loginPassword
      };
  
      try {
        // Make a GET request to fetch the actual password from the database
        const response = await axios.get('http://localhost:8080/auth/user/' + loginName);
        const actualPassword = response.data.password;
  
        if (actualPassword === loginPassword) {
          // Passwords match, login successful
          sessionStorage.setItem("user", JSON.stringify(user));
          window.location.href = "/home";
          alert("Login success");
  
          setEmail('');
          setPassword('');
          setUserName(user.name);
        } else {
          // Passwords don't match, login failed
          alert("Invalid credentials");
        }
      } catch (error) {
        // Handle error during login
        console.log(error);
      }
    }
  };
  

  const handleClick = () => {
    setShowReplacement(true);
  };

  return (
    <Container fluid>
      <Row>
        <div className='d-flex col-12'>
          <Col className='me-4 p-5' xs={12} lg={6} md={6}>
            {!showReplacement ? (
              <>
                <h4>Register</h4>
                <hr />
                <Form onSubmit={handleSubmit} className="was-validated">
                <Form.Group className='mb-4' controlId="text">
                    <Form.Label>Username:</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter username"
                      value={name}
                      onChange={(e) => setUserName(e.target.value)} required
                    />
                    <Form.Control.Feedback type="valid">Valid.</Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">Please fill out this field.</Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className='mb-4' controlId="email">
                    <Form.Label>Email address:</Form.Label>
                    <Form.Control
                      type="email"
                      placeholder="Enter email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)} required
                    />
                    <Form.Control.Feedback type="valid">Valid.</Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">Please fill out this field.</Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className='mb-4' controlId="password">
                    <Form.Label>Password:</Form.Label>
                    <Form.Control
                      type="password"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required/>
                      <Form.Control.Feedback type="valid">Valid.</Form.Control.Feedback>
                      <Form.Control.Feedback type="invalid">Please fill out this field.</Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className='mb-4' controlId="confirmPassword">
                    <Form.Label>Confirm Password:</Form.Label>
                    <Form.Control
                      type="password"
                      placeholder="Confirm Password"
                      value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
          isInvalid={passwordError}
        />
        {passwordError && (
          <Form.Control.Feedback type="invalid">
            Passwords do not match.
          </Form.Control.Feedback>
        )}
      </Form.Group>

                  <Button className='col-4 mt-2' variant="outline-primary" type="submit">
                    Register
                  </Button>

                  <hr />
                  <p className='mt-3'>
                    Already have an account? Click here to{' '}
                    <a href="#login" onClick={handleClick}>
                      Sign-In
                    </a>
                  </p>
                </Form>
              </>
            ) : (
              <>
                <div id="loginForm">
                  <h4>Login</h4>
                  <hr />
                  <Form onSubmit={handleLoginFormSubmit} className="was-validated">
      <Form.Group className="mb-1 mt-2">
        <Form.Label htmlFor="name">Email:</Form.Label>
        <Form.Control
          type="text"
          id="name"
          placeholder="Enter email address"
          name="name"
          value={loginName}
          onChange={(e) => setLoginName(e.target.value)}
          required
        />
        <Form.Control.Feedback type="valid">Valid.</Form.Control.Feedback>
        <Form.Control.Feedback type="invalid">Please fill out this field.</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-1">
        <Form.Label htmlFor="password">Password:</Form.Label>
        <Form.Control
          type="password"
          id="password"
          placeholder="Enter password"
          name="password"
          value={loginPassword}
          onChange={(e) => setPasswordLogin(e.target.value)}
          required
        />
        <Form.Control.Feedback type="valid">Valid.</Form.Control.Feedback>
        <Form.Control.Feedback type="invalid">Please fill out this field.</Form.Control.Feedback>
      </Form.Group>

      <div className="col-12">
        <Button type="submit" variant="outline-secondary" className="col-8 mt-2">
          Sign In
        </Button>
        <br />
        <FacebookLoginBtn />
      </div>
      <hr />
      <p>
        New User? Click here to <a href="register">Register</a>
      </p>
    </Form>
                </div>
              </>
            )}
          </Col>
          
          <Col className='my-auto backgr' xs={12} lg={6} md={6}>
            <div className=" col-12 blurbgr">
              <h1 className="display-2 text-white my-auto">Know Your neighborhood</h1>
              <hr className='text-white' />
              <p className="lead text-white">Register to enjoy all features.</p>
            </div>
          </Col>
        </div>
      </Row>
    </Container>
  );
};

export default RegisterForm;
