import React from 'react';
import FacebookLogin from '@greatsumini/react-facebook-login';
import { faFacebookF } from '@fortawesome/free-brands-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import axios from 'axios';

function FacebookLoginBtn(){

  const handleFacebookResponse = async (response) => {
    if (response.status !== "unknown") {
      sessionStorage.setItem("user", JSON.stringify(response));

      try {
        const checkLogin = await axios.post(
          "http://localhost:8080/user/login/facebook",
          response,
        );

        console.log(checkLogin.data);
        localStorage.setItem("token", checkLogin.data.token);
        window.location.href = "/";
    alert("Login successful!")

        
      } catch (error) {
        // Handle errors
        console.error(error);
      }
    } else {
      // Handle Facebook login failure
      console.log("Login Failed!", response);
    }
  };
  
    return (
      <>
      <div className="btnFesbuk btn col-8 mt-3">
      <span className='mx-2'>
<FontAwesomeIcon icon={faFacebookF} />
</span>
      <FacebookLogin className='btnFesbukDalem'
  appId="1405972086904241"
  
  onSuccess={(response) => {
    console.log('Login Success!', response);
  }}
  onFail={(error) => {
    console.log('Login Failed!', error);
  }}
  onProfileSuccess={(response) => {
    handleFacebookResponse(response);
    console.log('Get Profile Success!', response);
  }}
/>
      </div>
      </>
      
    );
  };
  
  export default FacebookLoginBtn;

  
