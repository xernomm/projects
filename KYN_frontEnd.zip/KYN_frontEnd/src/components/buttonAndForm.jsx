import { Container, Row, Col, Carousel, Button, Form} from 'react-bootstrap';
import FacebookLoginBtn from './FacebookLogin';
import React, { useState } from 'react';
import axios from 'axios';
import { decodeBase64 } from 'bcryptjs';
const ButtonAndForm = () => {
    
  const [name, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginName, setLoginName] = useState('');
  const [loginPassword, setPasswordLogin] = useState('');
  const [showReplacement, setShowReplacement] = useState(false);
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      setPasswordError(true);
      return;
    }
    const user = {
      name: name,
      email: email,
      password: password,
    };
  
    axios.post('http://localhost:8080/user/register', user)
      .then(response => {
       window.location.href = "/login"
        console.log(response.data);
      })
      .catch(error => {
        alert("Error Occured");
        console.error(error);
      });
      
  };

  const handleLogin = async (e) => {
    e.preventDefault(); // Prevent form submission
  
    // Create an object with the form data
    const user = {
      email: loginName,
      password: loginPassword
    };
  
    try {
      // Make the POST request using Axios to send user credentials to the server
      axios.post('http://localhost:8080/auth/login', user)
        .then((response) => {
          // Handle successful login
          sessionStorage.setItem("user", JSON.stringify(user));
          window.location.href = "/home";
          alert("Login success");
        })
        .catch((error) => {
          // Handle error during login
          if (error.response && error.response.status === 401) {
            alert("Invalid email or password");
          } else {
            alert("An error occurred. Please try again later.");
          }
        });
    } catch (error) {
      // Handle other errors
      console.log(error);
    }
    
  };
  

  const handleClick = () => {
    setShowReplacement(true);
  };

    return(
        
        <Col xs={12} lg={5} md={5} className="mx-auto my-auto px-5">
    
    {!showReplacement ? (
    <div id='replace' className="replace">
    
    <Button href='register' variant='primary' id='getStart' className='mt-4 col-12'>Get Started</Button>
    <br />
    <Button onClick={handleClick} variant='outline-secondary' id='signIn' className='my-3 col-12'>Sign In</Button>

    </div>
    ) : (
    <div id="loginForm">
  <Form onSubmit={handleLogin} className="was-validated">
      <Form.Group className="mb-1 mt-2">
        <Form.Label htmlFor="name">Email:</Form.Label>
        <Form.Control
          type="text"
          id="name"
          placeholder="Enter email address"
          name="name"
          value={loginName}
          onChange={(e) => setLoginName(e.target.value)}
          required
        />
        <Form.Control.Feedback type="valid">Valid.</Form.Control.Feedback>
        <Form.Control.Feedback type="invalid">Please fill out this field.</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-1">
        <Form.Label htmlFor="password">Password:</Form.Label>
        <Form.Control
          type="password"
          id="password"
          placeholder="Enter password"
          name="password"
          value={loginPassword}
          onChange={(e) => setPasswordLogin(e.target.value)}
          required
        />
        <Form.Control.Feedback type="valid">Valid.</Form.Control.Feedback>
        <Form.Control.Feedback type="invalid">Please fill out this field.</Form.Control.Feedback>
      </Form.Group>

      <div className="col-12">
        <Button type="submit" variant="outline-secondary" className="col-8 mt-2">
          Sign In
        </Button>
        <br />
        <FacebookLoginBtn />
      </div>
      <hr />
      <p>
        New User? Click here to <a href="register">Register</a>
      </p>
    </Form>
    </div>
    )}
    
</Col>

)

}

export default ButtonAndForm;
