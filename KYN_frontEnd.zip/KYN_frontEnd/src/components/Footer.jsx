import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebookF, faTwitter, faGoogle, faInstagram, faLinkedin, faGithub, faGem } from '@fortawesome/free-brands-svg-icons';
import { faHome, faEnvelope, faPhone, faPrint } from '@fortawesome/free-solid-svg-icons';
import img from '../img/logo.png'


function Footer() {
  return (
    <footer className="text-center text-lg-start bg-light text-dark">
      {/* Section: Social media */}
      <section className="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
        {/* Left */}
        <div className="me-5 d-none d-lg-block">
          <span>Get connected with us on social networks:</span>
        </div>
        {/* Left */}

        {/* Right */}
        <div>
          <a href="#" className="me-4 text-reset">
            <FontAwesomeIcon icon={faFacebookF} />
          </a>
          <a href="#" className="me-4 text-reset">
            <FontAwesomeIcon icon={faTwitter} />
          </a>
          <a href="#" className="me-4 text-reset">
            <FontAwesomeIcon icon={faGoogle} />
          </a>
          <a href="#" className="me-4 text-reset">
            <FontAwesomeIcon icon={faInstagram} />
          </a>
          <a href="#" className="me-4 text-reset">
            <FontAwesomeIcon icon={faLinkedin} />
          </a>
          <a href="#" className="me-4 text-reset">
            <FontAwesomeIcon icon={faGithub} />
          </a>
        </div>
        {/* Right */}
      </section>
      {/* Section: Social media */}

      {/* Section: Links */}
      <section>
        <Container className="text-center text-md-start mt-5">
          {/* Grid row */}
          <Row className="mt-3">
            {/* Grid column */}
            <Col md={6} lg={4} xl={3} className="mx-auto mb-4">
              {/* Content */}
              <span>
            <img style={{ height: "95px", width: "200px", marginRight: "10px" }} src={img} alt="logo" />
          </span>
              <p className='mt-5'>
              Our mission is to connect you with the people, places, and events that make your neighbourhood unique and vibrant.
              </p>
            </Col>
            {/* Grid column */}

            {/* Grid column */}
            <Col md={6} lg={2} xl={2} className="mx-auto mb-4">
              {/* Links */}
              <h6 className="text-uppercase text-dark fw-bold mb-4">STORES</h6>
              <p>
                <a href="register" className="text-reset text-decoration-none">Register Store</a>
              </p>
              <p>
                <a href="#" className="text-reset text-decoration-none">View all Store</a>
              </p>
            </Col>
            {/* Grid column */}

            {/* Grid column */}
            <Col md={6} lg={2} xl={2} className="mx-auto mb-4">
              {/* Links */}
              <h6 className="text-uppercase text-dark fw-bold mb-4">KYN</h6>
              <p>
                <a href="about_us" className="text-reset text-decoration-none">About Us</a>
              </p>
              <p>
                <a href="contact_us" className="text-reset text-decoration-none">Contact Us</a>
              </p>
              <p>
                <a href="terms" className='text-reset text-decoration-none'>Terms and Conditions</a>
              </p>
            </Col>
            {/* Grid column */}

            {/* Grid column */}
            <Col md={6} lg={4} xl={3} className="mx-auto mb-4">
              {/* Links */}
              <h6 className="text-uppercase text-dark fw-bold mb-4">Contact</h6>
              <p>
                <FontAwesomeIcon icon={faHome} className="me-3" />
                Indonesia, Banten 15326
              </p>
              <p>
                <FontAwesomeIcon icon={faEnvelope} className="me-3" />
                kyn@support.com
              </p>
              <p>
                <FontAwesomeIcon icon={faPhone} className="me-3" />
                +62 1656 85877
              </p>
              <p>
                <FontAwesomeIcon icon={faPrint} className="me-3" />
                +62 233 467 89
              </p>
            </Col>
            {/* Grid column */}
          </Row>
          {/* Grid row */}
        </Container>
      </section>
      {/* Section: Links */}

      {/* Copyright */}
      <div className="text-center p-4" style={{ backgroundColor: 'rgba(0, 0, 0, 0.05)' }}>
        &copy; 2023 Copyright:
        <a className="text-reset fw-bold" href="https://mdbootstrap.com/"> kyn.com</a>
      </div>
      {/* Copyright */}
    </footer>
  );
}

export default Footer;
