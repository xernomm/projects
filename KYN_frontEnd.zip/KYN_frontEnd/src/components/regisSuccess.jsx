import { Container, Row, Col, Carousel, Button, Form} from 'react-bootstrap';
import FacebookLoginBtn from './FacebookLogin';
import React, { useState } from 'react';
import axios from 'axios';

function RegisSuccess(){

   
        const [name, setUserName] = useState('');
        const [email, setEmail] = useState('');
        const [password, setPassword] = useState('');
        const [loginName, setLoginName] = useState('');
        const [loginPassword, setPasswordLogin] = useState('');
        const [showReplacement, setShowReplacement] = useState(false);
        const [confirmPassword, setConfirmPassword] = useState('');
        const [passwordError, setPasswordError] = useState(false);
      
      
      
        const handleSubmit = (e) => {
          e.preventDefault();
      
          if (password !== confirmPassword) {
            setPasswordError(true);
            return;
          }
          const user = {
            name: name,
            email: email,
            password: password,
          };
        
          axios.post('http://localhost:8080/user/register', user)
            .then(response => {
             window.location.href = "/login"
              console.log(response.data);
            })
            .catch(error => {
              alert("Error Occured");
              console.error(error);
            });
      
        };
      
        const handleLogin = async (e) => {
          e.preventDefault(); // Prevent form submission
        
          // Create an object with the form data
          const user = {
            email: loginName,
            password: loginPassword
          };
        
          try {
            // Make the POST request using Axios to send user credentials to the server
           axios.post('http://localhost:8080/auth/login', user).then((response)=>{
            sessionStorage.setItem("user", JSON.stringify(user))
            window.location.href = "/home"
            alert("Login success")
           });
        
            // Check if the server response contains a success message or token
            
          } catch (error) {
            alert("Invalid credentials");
            console.error(error);
            // Handle error during login
          }
        
          setEmail('');
          setPassword('');
        };
      
        const handleClick = () => {
          setShowReplacement(true);
        };
    return(
        <Container fluid>
        <Row>
          <div className='d-flex col-12'>
            <Col className='me-4 p-5' xs={12} lg={6} md={6}>
            
                <>
                  <div id="loginForm">
                    <h4>Login</h4>
                    <hr />
                    <Form onSubmit={handleLogin} className="was-validated">
      <Form.Group className="mb-1 mt-2">
        <Form.Label htmlFor="userName">Username:</Form.Label>
        <Form.Control
          type="text"
          id="userName"
          placeholder="Enter username"
          name="username"
          value={loginName}
          onChange={(e) => setLoginName(e.target.value)}
          required
        />
        <Form.Control.Feedback type="valid">Valid.</Form.Control.Feedback>
        <Form.Control.Feedback type="invalid">Please fill out this field.</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-1">
        <Form.Label htmlFor="password">Password:</Form.Label>
        <Form.Control
          type="password"
          id="password"
          placeholder="Enter password"
          name="password"
          value={loginPassword}
          onChange={(e) => setPasswordLogin(e.target.value)}
          required
        />
        <Form.Control.Feedback type="valid">Valid.</Form.Control.Feedback>
        <Form.Control.Feedback type="invalid">Please fill out this field.</Form.Control.Feedback>
      </Form.Group>

      <div className="col-12">
        <Button type="submit" variant="outline-secondary" className="col-8 mt-2">
          Sign In
        </Button>
        <br />
        <FacebookLoginBtn />
      </div>
      <hr />
      <p>
        New User? Click here to <a href="register">Register</a>
      </p>
    </Form>
                  </div>
                </>
             
            </Col>
            
            <Col className='my-auto ms-4 backgr' xs={12} lg={6} md={6}>
              <div className=" col-12 blurbgr">
                <h1 className="display-2 text-white my-auto">Know Your neighborhood</h1>
                <hr className='text-white' />
                <p className="lead text-white">Register to enjoy all features.</p>
              </div>
            </Col>
          </div>
        </Row>
      </Container>
    )
}

export default RegisSuccess;