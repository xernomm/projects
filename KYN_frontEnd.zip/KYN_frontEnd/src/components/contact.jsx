import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { useEffect, useState } from 'react';
import axios from 'axios';
import Form from 'react-bootstrap/Form'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapMarker, faPhone, faEnvelope } from '@fortawesome/free-solid-svg-icons';

function Contact(){
    const [messages, setMessages] = useState([]);

  const handleSubmit=(e) =>{
    e.preventDefault();
    console.log(messages)

    axios.post("http://localhost:8080/messages/XYZC4RS", 
    {text : messages}).then(()=>{
        window.location.href = "/contact";
    }).catch(()=>{
        alert("error has occured!")
    })
  };
    return(
        
    <Container>
      <Row>
      <Col className='mt-5'>
  <h2>Contact Us</h2>
  <hr />
  <p>Please leave us an email at kyn@support.com. We'll get back to you within 24 hours.</p>
  <p>
    <FontAwesomeIcon icon={faMapMarker} /> Indonesia, Banten
  </p>
  <p>
    <FontAwesomeIcon icon={faPhone} /> +62 1656 85877
  </p>
  <p>
    <FontAwesomeIcon icon={faEnvelope} /> kyn@support.com
  </p>
</Col>
      </Row>
      <br />
      <br />
      <Row>
        <Col>
          <h2>Where to Find Us</h2>
          <hr />
          <iframe
            className="col-12"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126904.38801812458!2d106.49540214335939!3d-6.294960199999981!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69fbae973fee4d%3A0xa5e6f881fdf49ffe!2sBursa%20Mobil%20BSD!5e0!3m2!1sid!2sid!4v1683299576637!5m2!1sid!2sid"
            width="600"
            height="450"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </Col>
        
        <hr className='my-4' />
        <div className="col-12 mb-5 d-flex">
            <div className="col-6 p-4 Leave">
                <h1 className='display-1'>Leave us a Message</h1>
                <p className="text-lead">We'd be happy to hear you!</p>
            </div>
            <Form onSubmit={handleSubmit}>
        <Form.Group className="p-4">
          <Form.Control
            as="textarea"
            rows={4}
            value={messages}
            onChange={(e) => setMessages(e.target.value)}
            style={{height:'200px',width:'500px'}}
          />
        </Form.Group>
        <div className="justify-content-center d-flex">
          <Button type="submit" variant="outline-success" className="col-6 mt-3">
            Submit
          </Button>
        </div>
      </Form>

        </div>
      </Row>


    </Container>
    )
    
}

export default Contact;